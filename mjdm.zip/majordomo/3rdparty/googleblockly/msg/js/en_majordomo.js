Blockly.Msg.MAJORDOMO_SAY = "say";
Blockly.Msg.MAJORDOMO_PRIORITY = "with priority";

Blockly.Msg.MAJORDOMO_RUNSCRIPT = "run script";
Blockly.Msg.MAJORDOMO_PARAMS = "with parameters";
Blockly.Msg.MAJORDOMO_OBJECT = "object";
Blockly.Msg.MAJORDOMO_PROPERTY = "property";
Blockly.Msg.MAJORDOMO_RUNMETHOD = "run method";
Blockly.Msg.MAJORDOMO_RUNMETHODCURRENT = "for current object run method";
Blockly.Msg.MAJORDOMO_GETGLOBAL = "get";
Blockly.Msg.MAJORDOMO_SETGLOBAL = "set";
Blockly.Msg.MAJORDOMO_PARAM = "Parameter";
Blockly.Msg.MAJORDOMO_KEY = "Set key";
Blockly.Msg.MAJORDOMO_VALUE = "value";
Blockly.Msg.MAJORDOMO_GETOBJECTS = "list of objects by class";

Blockly.Msg.MAJORDOMO_GETCURRENT = "get property value for current object";
Blockly.Msg.MAJORDOMO_SETCURRENT = "set property value for current object";

Blockly.Msg.MAJORDOMO_PHPEXPRESSION = "PHP-expression";
Blockly.Msg.MAJORDOMO_PHPCODE = "PHP-code";
Blockly.Msg.MAJORDOMO_GETRANDOMLINE = "random line from file";
Blockly.Msg.MAJORDOMO_GETURL = "get page by URL";
Blockly.Msg.MAJORDOMO_CALLURL = "HTTP-request by URL";
Blockly.Msg.MAJORDOMO_PLAYSOUND = "play sound file";

Blockly.Msg.MAJORDOMO_TIMEIS = "time is";
Blockly.Msg.MAJORDOMO_TIMENOW = "time now";
Blockly.Msg.MAJORDOMO_ISWEEKEND = "today is weekend";
Blockly.Msg.MAJORDOMO_ISWORKDAY = "today is workday";
Blockly.Msg.MAJORDOMO_TIMEBEFORE = "time before";
Blockly.Msg.MAJORDOMO_TIMEAFTER = "time after";
Blockly.Msg.MAJORDOMO_TIMEBETWEEN = "time between";
Blockly.Msg.MAJORDOMO_CLEARTIMEOUT = "clear timer";
Blockly.Msg.MAJORDOMO_SETTIMEOUT = "set timer with name";
Blockly.Msg.MAJORDOMO_SETTIMEOUTDELAY = "delay (sec)";
Blockly.Msg.MAJORDOMO_SETTIMEOUTOPERATIONS = "actions";

Blockly.Msg.MAJORDOMO_COLOR = "Color";

Blockly.Msg.MAJORDOMO_SETTO = "to";
