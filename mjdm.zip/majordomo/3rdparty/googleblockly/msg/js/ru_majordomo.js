Blockly.Msg.MAJORDOMO_SAY = "произнести";
Blockly.Msg.MAJORDOMO_PRIORITY = "с приоритетом";
Blockly.Msg.MAJORDOMO_RUNSCRIPT = "запустить сценарий";
Blockly.Msg.MAJORDOMO_PARAMS = "с параметрами";
Blockly.Msg.MAJORDOMO_OBJECT = "объекта";
Blockly.Msg.MAJORDOMO_PROPERTY = "свойство";
Blockly.Msg.MAJORDOMO_RUNMETHOD = "запустить метод";
Blockly.Msg.MAJORDOMO_RUNMETHODCURRENT = "запустить для текущего объекта метод";
Blockly.Msg.MAJORDOMO_GETGLOBAL = "получить";
Blockly.Msg.MAJORDOMO_SETGLOBAL = "установить";
Blockly.Msg.MAJORDOMO_PARAM = "Параметр";
Blockly.Msg.MAJORDOMO_KEY = "Установить ключ";
Blockly.Msg.MAJORDOMO_VALUE = "значение";
Blockly.Msg.MAJORDOMO_GETOBJECTS = "список объектов класса";

Blockly.Msg.MAJORDOMO_GETCURRENT = "получить для текущего объекта";
Blockly.Msg.MAJORDOMO_SETCURRENT = "установить для текущего объекта";

Blockly.Msg.MAJORDOMO_PHPEXPRESSION = "PHP-выражение";
Blockly.Msg.MAJORDOMO_PHPCODE = "PHP-код";
Blockly.Msg.MAJORDOMO_GETRANDOMLINE = "случайная строка из файла";
Blockly.Msg.MAJORDOMO_GETURL = "получить страницу по ссылке";
Blockly.Msg.MAJORDOMO_CALLURL = "HTTP-запрос по ссылке";
Blockly.Msg.MAJORDOMO_PLAYSOUND = "проиграть звуковой файл";

Blockly.Msg.MAJORDOMO_TIMEIS = "наступило время";
Blockly.Msg.MAJORDOMO_TIMENOW = "текущее время";
Blockly.Msg.MAJORDOMO_ISWEEKEND = "сегодня выходной";
Blockly.Msg.MAJORDOMO_ISWORKDAY = "сегодня рабочий день";
Blockly.Msg.MAJORDOMO_TIMEBEFORE = "время ранее";
Blockly.Msg.MAJORDOMO_TIMEAFTER = "время после";
Blockly.Msg.MAJORDOMO_TIMEBETWEEN = "время в промежутке";
Blockly.Msg.MAJORDOMO_CLEARTIMEOUT = "очистить таймер с именем";
Blockly.Msg.MAJORDOMO_SETTIMEOUT = "создать таймер отложенного запуска с именем";
Blockly.Msg.MAJORDOMO_SETTIMEOUTDELAY = "задержкой (сек)";
Blockly.Msg.MAJORDOMO_SETTIMEOUTOPERATIONS = "действия";

Blockly.Msg.MAJORDOMO_COLOR = "Цвет";

Blockly.Msg.MAJORDOMO_SETTO = "в";
